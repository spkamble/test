This media allows you to install other medias.
